
--Cyber, Sapling and Axolotl were here :3

local l = bl and 1 or -1

global.foodCount = 0.0;
global.foodCountO = 0.0;

local easedFoodCounter = Easings:easeInQuart(mainHand and foodCount or foodCountO)

if (
    I:isOf(item, Items:get("minecraft:bucket")) or
    I:isOf(item, Items:get("minecraft:axolotl_bucket")) or
    I:isOf(item, Items:get("minecraft:powder_snow_bucket")) or
    I:isOf(item, Items:get("minecraft:pufferfish_bucket")) or
    I:isOf(item, Items:get("minecraft:tadpole_bucket")) or
    I:isOf(item, Items:get("minecraft:salmon_bucket")) or
    I:isOf(item, Items:get("minecraft:cod_bucket")) or
    I:isOf(item, Items:get("minecraft:tropical_fish_bucket")) or
    I:isOf(item, Items:get("minecraft:water_bucket"))
) then
    M:moveY(matrices, 0.025)
    M:moveX(matrices, -0 * l)
    M:moveZ(matrices, -0.1)
    M:rotateY(matrices, 180)
    M:rotateX(matrices, -82.5)
    M:rotateZ(matrices, -20 * l)
end
if I:isOf(item, Items:get("minecraft:milk_bucket")) then
    M:moveY(matrices, 0.025)
    M:moveX(matrices, -0 * l)
    M:moveZ(matrices, -0.1)
    M:rotateY(matrices, 180)
    M:rotateX(matrices, -82.5)
    M:rotateZ(matrices, -20 * l)
    M:rotateX(matrices, -0 * easedFoodCounter)
    M:rotateZ(matrices, 30 * l * easedFoodCounter)
    M:rotateY(matrices, 0 * l * easedFoodCounter)
    M:moveX(matrices, 0 * l * easedFoodCounter)
    M:moveY(matrices, 0.1 * easedFoodCounter)
    M:moveZ(matrices, 0.02 * easedFoodCounter)
end
if I:isOf(item, Items:get("minecraft:lava_bucket")) then
    M:moveY(matrices, 0.025)
    M:moveX(matrices, -0 * l)
    M:moveZ(matrices, -0.1)
    M:rotateY(matrices, 180)
    M:rotateX(matrices, -82.5)
    M:rotateZ(matrices, -20 * l)
    I:setTranslate(item, true)
    
    particleManager:addParticle(
        particles, 
        false, 
        -0.05 * l, 
        0, 
        0, 
        0, 
        0, 
        0, 
        0, 
        0, 
        0, 
        0, 
        0, 
        0, 
        2, 
        Texture:of("minecraft", "textures/particle/glow.png"), 
        "ITEM", 
        hand, 
        "SPAWN", 
        "ADDITIVE", 
        0, 
        150 + (20 * M:sin(P:getAge(player) * 0.2))
    )
end